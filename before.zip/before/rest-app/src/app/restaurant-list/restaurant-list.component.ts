import { Component, OnInit } from '@angular/core';
import { IRestaurant } from '../restaurant';
import { RestaurantService } from '../restaurant.service';

@Component({
  templateUrl: './restaurant-list.component.html',
  styleUrls: ['./restaurant-list.component.css']
})
export class RestaurantListComponent implements OnInit {

  listFilter: string='';
  imageWidth:number = 150;
  pageTitle :string ="RMS";
  restaurants: IRestaurant[];
 showImage: boolean = false;

  constructor(public _restService : RestaurantService) {
    
   }
toggleImage() : void{
    this.showImage= !this.showImage;
}
  ngOnInit() {
    this.restaurants = this._restService.getRestaurants();
  
  }

}
