import { Component, OnInit } from '@angular/core';
import { IRestaurant } from '../restaurant';

@Component({
  selector: 'app-add-restaurant',
  templateUrl: './add-restaurant.component.html',
  styleUrls: ['./add-restaurant.component.css']
})
export class AddRestaurantComponent implements OnInit {

  pageTitle :string ="RMS";
  
  constructor() { }

  ngOnInit() {
  }

  addRestaurant(formValues: any): void {
    let newRestaurant: IRestaurant = <IRestaurant>formValues;
    console.log(newRestaurant);
    console.warn('Add new restaurnat not yet implemented.');
  }

}
