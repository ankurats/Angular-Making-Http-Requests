import { Component, OnInit } from '@angular/core';
import {ActivatedRoute, Router} from '@angular/router';
import { RestaurantService } from '../restaurant.service';
import { IRestaurant } from '../restaurant';
@Component({
  selector: 'app-restaurant-details',
  templateUrl: './restaurant-details.component.html',
  styleUrls: ['./restaurant-details.component.css']
})
export class RestaurantDetailsComponent implements OnInit {
  id: number;
  restaurant : IRestaurant;
  imageWidth:number = 150;
  constructor(private route: ActivatedRoute, private router:Router, private restService : RestaurantService) {
   }

  ngOnInit() {
    this.id = +this.route.snapshot.paramMap.get('id');
    this.restaurant = this.restService.getRestaurantById(this.id);
  }

  goBack() : void{
this.router.navigate(['/restaurant']);
  }
}
