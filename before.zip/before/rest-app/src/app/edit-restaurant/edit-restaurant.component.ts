import { Component, OnInit } from '@angular/core';
import {ActivatedRoute} from '@angular/router';
import { IRestaurant } from '../restaurant';
import { RestaurantService } from '../restaurant.service';
@Component({
  selector: 'app-edit-restaurant',
  templateUrl: './edit-restaurant.component.html',
  styleUrls: ['./edit-restaurant.component.css']
})
export class EditRestaurantComponent implements OnInit {

  id: number;
  restaurant : IRestaurant;

  constructor(private route: ActivatedRoute,private restService : RestaurantService) { }

  ngOnInit() {
    this.id = +this.route.snapshot.paramMap.get('id');
    this.restaurant = this.restService.getRestaurantById(this.id);
  }

  saveChanges(): void {
    console.warn('Save changes to restaurant not yet implemented.');
  }
}
