import { Component, OnInit } from '@angular/core';
import { IRestaurant } from '../restaurant';
import { RestaurantService } from '../restaurant.service';

@Component({
  templateUrl: './restaurant-list.component.html',
  styleUrls: ['./restaurant-list.component.css']
})
export class RestaurantListComponent implements OnInit {

  listFilter: string='';
  imageWidth:number = 150;
  pageTitle :string ="RMS";
  restaurants: IRestaurant[];
 showImage: boolean = false;

  constructor(public _restService : RestaurantService) {
    
   }
toggleImage() : void{
    this.showImage= !this.showImage;
}
  ngOnInit() {
    
 // To use the promise 
    this._restService.getRestaurants()
    .then(
      rest => {
        console.log(rest);
        this.restaurants  = rest;
      }
    );

    // to use observable 

  //  var subs= this._restService.getRestaurants().subscribe(
  //     data => this.restaurants=data,
  //     (err:any) =>  console.log(err),
  //     () => console.log('all done !!')
  //   )


  }
  deleteRestaurant(id : number) : void{
    this._restService.deleteRestaurant(id).subscribe(
      (data:void) => {
        let index : number = this.restaurants.findIndex(rest => rest.id == id);
        this.restaurants.splice(index,1);
      },
      err=> console.log(err)
    )
  }
}
