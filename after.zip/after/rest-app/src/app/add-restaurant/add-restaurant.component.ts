import { Component, OnInit } from '@angular/core';
import { IRestaurant } from '../restaurant';
import { RestaurantService } from '../restaurant.service';

@Component({
  selector: 'app-add-restaurant',
  templateUrl: './add-restaurant.component.html',
  styleUrls: ['./add-restaurant.component.css']
})
export class AddRestaurantComponent implements OnInit {

  pageTitle :string ="RMS";
  
  constructor(private restService : RestaurantService) { }

  ngOnInit() {
  }

  addRestaurant(formValues: any): void {
    let newRestaurant: IRestaurant = <IRestaurant>formValues;
    console.log(newRestaurant);
    //console.warn('Add new restaurnat not yet implemented.');
    this.restService.addRestaurant(newRestaurant).subscribe(
        data => console.log(data),
        err => console.log(err)
    );
  }

}
