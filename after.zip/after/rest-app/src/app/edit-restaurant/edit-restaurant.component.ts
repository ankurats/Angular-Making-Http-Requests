import { Component, OnInit } from '@angular/core';
import {ActivatedRoute} from '@angular/router';
import { IRestaurant } from '../restaurant';
import { RestaurantService } from '../restaurant.service';
@Component({
  selector: 'app-edit-restaurant',
  templateUrl: './edit-restaurant.component.html',
  styleUrls: ['./edit-restaurant.component.css']
})
export class EditRestaurantComponent implements OnInit {

  id: number;
  restaurant : IRestaurant;

  constructor(private route: ActivatedRoute,private restService : RestaurantService) { }

  ngOnInit() {
    this.id = +this.route.snapshot.paramMap.get('id');
   // this.restaurant = this.restService.getRestaurantById(this.id);
   
     this.restService.getRestaurantById(this.id).subscribe(
        data => this.restaurant = data
     )
   ;
  }

  saveChanges(): void {
   // console.warn('Save changes to restaurant not yet implemented.');
   this.restService.updateRestaurant(this.restaurant)
   .subscribe(
     (data:void) => console.log(`${this.restaurant.restaurantTitle} updated successfully !!`),
     err => console.log(err)
   );
  }
}
