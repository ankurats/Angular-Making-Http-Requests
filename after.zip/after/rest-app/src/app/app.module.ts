import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {FormsModule} from '@angular/forms';
import { AppComponent } from './app.component';
import { RestaurantListComponent } from './restaurant-list/restaurant-list.component';
import { RestaurantFilterPipe } from './restaurant-filter.pipe';
import { RestaurantService } from './restaurant.service';
import { StarComponent } from './Shared/star/star.component';
import { WelcomeComponent } from './welcome/welcome.component';
import { RestaurantDetailsComponent } from './restaurant-details/restaurant-details.component';
import {RouterModule } from '@angular/router';
import { AddRestaurantComponent } from './add-restaurant/add-restaurant.component';
import { EditRestaurantComponent } from './edit-restaurant/edit-restaurant.component';
import {HttpClientModule} from '@angular/common/http';

@NgModule({
  declarations: [
    AppComponent,
    RestaurantListComponent,
    RestaurantFilterPipe,
    StarComponent,
    WelcomeComponent,
    RestaurantDetailsComponent,
    AddRestaurantComponent,
    EditRestaurantComponent
  ],
  imports: [
    BrowserModule,
    HttpClientModule,
    FormsModule,
    RouterModule.forRoot([
      {path: 'restaurant', component: RestaurantListComponent},
      {path: 'home', component: WelcomeComponent},
      {path:'restaurants/:id/:name',component: RestaurantDetailsComponent},
      {path: 'addrestaurant' ,component: AddRestaurantComponent},
      {path: 'editrestaurant/:id' ,component: EditRestaurantComponent},
      {path:'', component: WelcomeComponent},
      {path:'**', redirectTo:'home'},

    ])
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }

