export interface IRestaurant {
    id: number;
    restaurantTitle: string;
    restaurantCity: string;
    restaurantState: string;
    starRating: number;
    imageUrl: string;
}
