import { Injectable } from '@angular/core';
import { IRestaurant } from './restaurant';
import { AppModule } from './app.module';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from '../../node_modules/rxjs';
@Injectable()
export class RestaurantService {
  restList: IRestaurant[] = null;

  constructor(private http: HttpClient) { }

  getRestaurantById(id: number): Observable<IRestaurant> {
    //return this.restList.find(restaurant => restaurant.id === id);
    return this.http.get<IRestaurant>(`http://localhost:3000/restaurants/${id}`);
  }

  // To return promise 
  getRestaurants(): Promise<IRestaurant[]> {
    return this.http.get<IRestaurant[]>("http://localhost:3000/restaurants")
      .toPromise<IRestaurant[]>();
  }

  // To return  Observable

  // getRestaurants() :Observable<IRestaurant[]>{
  //   // return this.restList;
  //   return this.http.get<IRestaurant[]>("http://localhost:3000/restaurants");
  // }

  addRestaurant(newRestaurant: IRestaurant): Observable<IRestaurant> {
    return this.http.post<IRestaurant>('http://localhost:3000/restaurants', newRestaurant, {
      headers: new HttpHeaders({
        'Content-Type': 'application/json'
      })
    });
  }

  updateRestaurant(updateRestaurant: IRestaurant): Observable<void> {
    return this.http.put<void>(`http://localhost:3000/restaurants/${updateRestaurant.id}`, updateRestaurant, {
      headers: new HttpHeaders({
        'Content-Type': 'application/json'
      })
    });
  }

  deleteRestaurant(id: number): Observable<void> {
    return this.http.delete<void>(`http://localhost:3000/restaurants/${id}`);
  }
}
